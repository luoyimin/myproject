-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2018-12-20 08:10:05
-- 服务器版本： 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `starsea`
--

-- --------------------------------------------------------

--
-- 表的结构 `ss_auth`
--

CREATE TABLE `ss_auth` (
  `auth_id` smallint(6) UNSIGNED NOT NULL,
  `auth_name` varchar(20) NOT NULL COMMENT '权限名称',
  `auth_pid` smallint(6) UNSIGNED NOT NULL COMMENT '父id',
  `auth_c` varchar(32) NOT NULL DEFAULT '' COMMENT '控制器',
  `auth_a` varchar(32) NOT NULL DEFAULT '' COMMENT '操作方法',
  `auth_path` varchar(32) NOT NULL DEFAULT '''''' COMMENT '全路径',
  `auth_level` tinyint(4) NOT NULL DEFAULT '0' COMMENT '级别'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ss_auth`
--

INSERT INTO `ss_auth` (`auth_id`, `auth_name`, `auth_pid`, `auth_c`, `auth_a`, `auth_path`, `auth_level`) VALUES
(100, '部门管理', 0, '', '', '100', 0),
(101, '行政管理', 0, '', '', '101', 0),
(102, '权限管理', 0, '', '', '102', 0),
(103, '部门列表', 100, 'Goods', 'showlist', '100-103', 1),
(104, '添加部门', 100, 'Goods', 'add', '100-104', 1),
(106, '行政列表', 101, 'Order', 'showlist', '101-106', 1),
(107, '行政官', 101, 'Order', 'look', '101-107', 1),
(108, '行政处理', 101, 'Order', 'dayin', '101-108', 1),
(111, '权限列表', 102, 'Auth', 'showlist', '102-111', 1),
(112, '人事管理', 0, '', '', '112', 0),
(113, '员工列表', 112, 'User', 'showlist', '112-113', 1),
(115, '添加员工', 112, 'User', 'tianjia', '112-115', 1),
(116, '添加权限', 102, 'Auth', 'tianjia', '102-116', 1),
(123, '角色管理', 0, '', '', '123', 0),
(124, '角色列表', 123, 'Role', 'showlist', '123-124', 1),
(125, '添加角色', 123, 'Role', 'tianjia', '123-125', 1),
(126, '管理员管理', 0, '', '', '126', 0),
(127, '管理员列表', 126, 'Manager', 'showlist', '126-127', 1),
(128, '添加管理员', 126, 'Manager', 'tianjia', '126-128', 1),
(129, '修改管理员信息', 126, 'Manager', 'update', '126-129', 1),
(130, '修改权限信息', 102, 'Auth', 'update', '102-130', 1),
(131, '修改权限', 123, 'Role', 'update', '123-131', 1),
(132, '修改员工信息', 112, 'User', 'update', '112-132', 1),
(133, '删除员工', 112, 'User', 'del', '112-133', 1),
(134, '删除角色', 123, 'Role', 'del', '123-134', 1),
(135, '删除管理员', 126, 'Manager', 'del', '126-135', 1),
(136, '删除权限', 102, 'Auth', 'del', '102-136', 1),
(137, '系统管理', 0, '', '', '137', 0),
(138, '数据管理', 0, '', '', '138', 0),
(139, '财务管理', 0, '', '', '139', 0),
(140, '物资管理', 0, '', '', '140', 0),
(141, '质量管理', 0, '', '', '141', 0),
(142, '设备管理', 0, '', '', '142', 0),
(143, '客户关系管理', 0, '', '', '143', 0),
(144, '项目管理', 0, '', '', '144', 0),
(145, '关于公司', 0, '', '', '145', 0);

-- --------------------------------------------------------

--
-- 表的结构 `ss_manager`
--

CREATE TABLE `ss_manager` (
  `mg_id` int(20) NOT NULL,
  `mg_name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `mg_pwd` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `mg_phone` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '照片',
  `mg_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mg_role_id` int(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `ss_manager`
--

INSERT INTO `ss_manager` (`mg_id`, `mg_name`, `mg_pwd`, `mg_phone`, `mg_time`, `mg_role_id`) VALUES
(1, 'xiaoming', '123456', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '2018-10-31 16:00:00', 10),
(2, 'xiaohua', '123456', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '2018-11-01 16:00:00', 11),
(5, 'admin', '123456', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '2018-11-30 16:00:00', 0),
(6, '星海', '123456', 'Public/uploads/2018-12-17/5c17882beeb8b.jpg', '2018-12-17 11:28:28', 10),
(10, '李志远', '123456', 'Public/uploads/2018-12-20/5c1b1b2eb35a3.jpg', '2018-12-20 04:31:42', 16),
(11, '梁英杰', '123456', 'Public/uploads/2018-12-20/5c1b1b4e66927.jpg', '2018-12-20 04:32:14', 13),
(12, '刘浩宇', '123456', 'Public/uploads/2018-12-20/5c1b1b71701ad.jpg', '2018-12-20 04:32:49', 16),
(13, '李静佳', '123456', 'Public/uploads/2018-12-20/5c1b1bb3713d3.jpg', '2018-12-20 04:33:55', 12),
(14, '沈明喜', '123456', 'Public/uploads/2018-12-20/5c1b1bd653e1d.jpg', '2018-12-20 04:34:30', 13),
(15, '李婉莹', '123456', 'Public/uploads/2018-12-20/5c1b1bffd2e09.jpg', '2018-12-20 04:35:11', 12),
(16, '刘奕蓝', '123456', 'Public/uploads/2018-12-20/5c1b1c3b1ce11.jpg', '2018-12-20 04:36:11', 15);

-- --------------------------------------------------------

--
-- 表的结构 `ss_role`
--

CREATE TABLE `ss_role` (
  `role_id` smallint(6) UNSIGNED NOT NULL,
  `role_name` varchar(20) NOT NULL COMMENT '角色名称',
  `role_auth_ids` varchar(128) NOT NULL DEFAULT '' COMMENT '权限ids,1,2,5',
  `role_auth_ac` text COMMENT '控制器-操作方法，控制器-操作方法，控制器-操作方法'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ss_role`
--

INSERT INTO `ss_role` (`role_id`, `role_name`, `role_auth_ids`, `role_auth_ac`) VALUES
(10, '主管', '100,104,105,101,106,102,112,113', 'Goods-add,Goods-category,Order-showlist,User-showlist'),
(11, '经理', '100,104,101,106,107,108,112,113', 'Goods-tianjiia,Order-showlist,Order-look,Order-dayin,User-showlist'),
(12, '总经理', '', 'Goods-showlist,Goods-add,Goods-category,Order-showlist,Order-look,Order-dayin,Auth-showlist,User-showlist,User-tianjia,Auth-tianjia,Role-showlist,Role-tianjia,Manager-showlist,Manager-tianjia,Manager-update,Auth-update,Role-update,User-update,User-del,Role-del,Manager-del,Auth-del'),
(13, '销售经理', '', 'Goods-showlist,Goods-add,Goods-category,Order-showlist,Order-look,Order-dayin,Auth-showlist,User-showlist,User-tianjia,Auth-tianjia,Role-showlist,Role-tianjia,Manager-showlist,Manager-tianjia,Manager-update,Auth-update,Role-update,User-update,User-del,Role-del,Manager-del,Auth-del'),
(14, '董事长', '', 'Goods-showlist,Goods-add,Goods-category,Order-showlist,Order-look,Order-dayin,Auth-showlist,User-showlist,User-tianjia,Auth-tianjia,Role-showlist,Role-tianjia,Manager-showlist,Manager-tianjia,Manager-update,Auth-update,Role-update,User-update,User-del,Role-del,Manager-del,Auth-del'),
(15, '技术人员', '', 'Goods-showlist,Goods-add,Goods-category,Order-showlist,Order-look,Order-dayin,Auth-showlist,User-showlist,User-tianjia,Auth-tianjia,Role-showlist,Role-tianjia,Manager-showlist,Manager-tianjia,Manager-update,Auth-update,Role-update,User-update,User-del,Role-del,Manager-del,Auth-del'),
(16, '会计', '', 'Goods-showlist,Goods-add,Goods-category,Order-showlist,Order-look,Order-dayin,Auth-showlist,User-showlist,User-tianjia,Auth-tianjia,Role-showlist,Role-tianjia,Manager-showlist,Manager-tianjia,Manager-update,Auth-update,Role-update,User-update,User-del,Role-del,Manager-del,Auth-del');

-- --------------------------------------------------------

--
-- 表的结构 `ss_sections`
--

CREATE TABLE `ss_sections` (
  `se_id` int(20) NOT NULL COMMENT '部门id',
  `se_name` varchar(125) NOT NULL COMMENT '部门名称'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ss_sections`
--

INSERT INTO `ss_sections` (`se_id`, `se_name`) VALUES
(1, '技术部'),
(2, '运维部'),
(3, '财务部'),
(4, '行政部'),
(5, '人事部'),
(6, '推广部'),
(7, '客服部'),
(8, '外联部');

-- --------------------------------------------------------

--
-- 表的结构 `ss_user`
--

CREATE TABLE `ss_user` (
  `user_id` int(11) NOT NULL COMMENT '自增id',
  `user_number` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT '编号',
  `user_name` varchar(125) CHARACTER SET utf8 NOT NULL COMMENT '姓名',
  `user_xueli` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '学历',
  `user_phone` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '照片',
  `user_photo` varchar(11) CHARACTER SET utf8 NOT NULL COMMENT '手机',
  `user_card` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '身份证',
  `user_section_id` int(20) DEFAULT NULL COMMENT '部门',
  `user_entrytable` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '入职表',
  `user_leavetable` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '离职表',
  `user_now` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '在职' COMMENT '状态',
  `user_entrytime` datetime DEFAULT NULL COMMENT '入职时间',
  `user_leavetime` datetime DEFAULT NULL COMMENT '离职时间',
  `user_resume` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '简历',
  `user_post` varchar(125) CHARACTER SET utf8 DEFAULT NULL COMMENT '职位',
  `user_money` int(20) DEFAULT NULL COMMENT '薪水'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='人员表';

--
-- 转存表中的数据 `ss_user`
--

INSERT INTO `ss_user` (`user_id`, `user_number`, `user_name`, `user_xueli`, `user_phone`, `user_photo`, `user_card`, `user_section_id`, `user_entrytable`, `user_leavetable`, `user_now`, `user_entrytime`, `user_leavetime`, `user_resume`, `user_post`, `user_money`) VALUES
(49, '1630435', '罗义旻', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320178502', '441225199902035612', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '部长', 13020),
(50, '1630488', '纳兰可儿', '本科', 'Public/uploads/2018-12-18/5c18b98da1521.jpg', '18320178522', '12345678978945612x', 7, NULL, NULL, '在职', '2018-12-18 00:00:00', NULL, NULL, '销售员', 7000),
(51, '1630479', '刘怡然', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320178589', '441225199902035645', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '部长', 13574),
(52, '1630499', '刘然', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320458589', '441225199122035645', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '员工', 56574),
(53, '1630465', '李维一', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320412589', '441225199122045645', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '员工', 58574),
(54, '1630469', '李玉文', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320438589', '441225239122035645', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '员工', 56374),
(55, '1630492', '刘亦菲', '大专', 'Public/uploads/2018-11-26/5bfb6a539827b.jpg', '18320238589', '441225194322035645', 1, NULL, NULL, '在职', '2018-09-13 00:00:00', NULL, NULL, '员工', 5574),
(56, '1630483', '纳兰雨', '本科', 'Public/uploads/2018-12-18/5c18b98da1521.jpg', '18320138522', '12345678978945612x', 7, NULL, NULL, '在职', '2018-12-18 00:00:00', NULL, NULL, '销售员', 8000),
(57, '1630484', '纳兰怡', '本科', 'Public/uploads/2018-12-18/5c18b98da1521.jpg', '18320138522', '12345678978945612x', 7, NULL, NULL, '在职', '2018-12-18 00:00:00', NULL, NULL, '销售员', 4000),
(58, '1630485', '纳兰雄安', '本科', 'Public/uploads/2018-12-18/5c18b98da1521.jpg', '18320458522', '12345678978945612x', 7, NULL, NULL, '在职', '2018-12-18 00:00:00', NULL, NULL, '销售员', 8034);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ss_auth`
--
ALTER TABLE `ss_auth`
  ADD PRIMARY KEY (`auth_id`);

--
-- Indexes for table `ss_manager`
--
ALTER TABLE `ss_manager`
  ADD PRIMARY KEY (`mg_id`);

--
-- Indexes for table `ss_role`
--
ALTER TABLE `ss_role`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `ss_sections`
--
ALTER TABLE `ss_sections`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `ss_user`
--
ALTER TABLE `ss_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_number` (`user_number`),
  ADD UNIQUE KEY `user_number_2` (`user_number`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `ss_auth`
--
ALTER TABLE `ss_auth`
  MODIFY `auth_id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;
--
-- 使用表AUTO_INCREMENT `ss_manager`
--
ALTER TABLE `ss_manager`
  MODIFY `mg_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- 使用表AUTO_INCREMENT `ss_role`
--
ALTER TABLE `ss_role`
  MODIFY `role_id` smallint(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- 使用表AUTO_INCREMENT `ss_sections`
--
ALTER TABLE `ss_sections`
  MODIFY `se_id` int(20) NOT NULL AUTO_INCREMENT COMMENT '部门id', AUTO_INCREMENT=9;
--
-- 使用表AUTO_INCREMENT `ss_user`
--
ALTER TABLE `ss_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增id', AUTO_INCREMENT=59;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
